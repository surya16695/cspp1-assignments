'''
Write a function to tokenize a given string and return a dictionary with the frequency of
each word
'''

def tokenize(string):
    pass
            
def main():
    pass

if __name__ == '__main__':
    main()
